# Transcripteur Yoruba – Version GitHub prête

Frontend + Backend + Workflow GitHub Pages.